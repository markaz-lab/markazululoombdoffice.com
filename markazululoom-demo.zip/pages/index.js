import Head from 'next/head';
import Image from 'next/image';
import styles from '../styles/globals.css';

export default function Home() {
  return (
    <div>
      <Head>
        <title>Markazul Uloom Al Islamia Bangladesh</title>
      </Head>
      <header>
        <Image src="/banner.jpg" alt="Header Banner" width={1200} height={200} />
        <Image src="/logo.png" alt="Logo" width={150} height={150} />
        <h1>মারকাজুল উলুম আল ইসলামিয়া বাংলাদেশ</h1>
      </header>
      <main>
        <h2>স্বাগতম</h2>
        <p>এটি একটি ডেমো ডায়নামিক ওয়েবসাইট। ইনশাআল্লাহ ভবিষ্যতে আরও ফিচার যুক্ত হবে।</p>
        <ul>
          <li>পরিচিতি</li>
          <li>বিভাগসমূহ</li>
          <li>শিক্ষা কার্যক্রম</li>
          <li>শিক্ষকমণ্ডলী</li>
          <li>লাইব্রেরি</li>
          <li>হোস্টেল সুবিধা</li>
          <li>ফি ও বেতন</li>
          <li>দাতা ও সহযোগীগণ</li>
          <li>ফটো গ্যালারি</li>
          <li>ভিডিও গ্যালারি</li>
        </ul>
      </main>
    </div>
  );
}